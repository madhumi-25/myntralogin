package StepDefinition;

import org.openqa.selenium.WebDriver;



import Pages.MyntraLoginPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {

	public WebDriver driver;
	MyntraLoginPage login;
	
	@Given("^User is able to launch the Chrome application$")
	public void user_is_able_to_launch_the_Chrome_application() throws Throwable {
		login = new MyntraLoginPage(driver);
	    login.launchBrowser("firefox");
	}

	@When("^Enter URL for Myntra home page$")
	public void enter_URL_for_Myntra_home_page() throws Throwable {
	    login.openWebsite();
	}

	@Then("^click on login/signup button$")
	public void click_on_login_signup_button() throws Throwable {
	    login.loginPageClick();
	}

	@Then("^Enter valid phone number$")
	public void enter_valid_phone_number() throws Throwable {
	    login.phoneNo("9597163236");
	}

	@Then("^click on continue and click on password$")
	public void click_on_continue_and_click_on_password() throws Throwable {
	    login.clickContinueAndPassword();
	}

	@Then("^Enter password and submit$")
	public void enter_password_and_submit() throws Throwable {
	    login.enterPasswordAndclickLoginButton("Madhu@25");
	}

}
