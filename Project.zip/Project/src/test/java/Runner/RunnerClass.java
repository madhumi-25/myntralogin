package Runner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
	@CucumberOptions 
		(
			features = "src/main/resources/Feature/MyntraLogin.feature",
//			plugin = {"pretty", "html:reports/cucumber-html-report","json:reports/cucumber-json-report/jsonreport","com.cucumber.listener.ExtentCucumberFormatter:reports/cucumber-extent-report/extentreport.html"},
//			tags = {"@TC_03_Adding_books_from_HTML_Category"},
			glue = {"StepDefinition"},
			monochrome = true
	
				)
	public class RunnerClass {
}
	
