package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pages.LoginPage;
import cucumber.api.PendingException;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyntraLoginSteps {
	
	WebDriver driver;
	public LoginPage login;
	
	@Given("^User is able to launch the Chrome application$")
	public void user_is_able_to_launch_the_Chrome_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Drivers\\chromedriver.exe");
	}

	@When("^Enter URL for Myntra home page$")
	public void Enter_URL_for_Myntra_home_page() throws Throwable {
		driver.get("https://www.myntra.com/");
	}

	@Then("^click on login/signup button$")
	public void click_on_login_signup_button() throws Throwable {
	    driver.findElement(By.linkText("login / Signup")).click();
	}

	@Then("^Enter valid phone number$")
	public void enter_valid_phone_number() throws Throwable {
	    driver.findElement(By.className("form-control mobileNumberInput")).sendKeys("9597163236");
	}

	@Then("^click on continue and click on password$")
	public void click_on_continue_and_click_on_password() throws Throwable {
		driver.findElement(By.linkText("CONTINUE")).click();
		driver.findElement(By.linkText(" Password ")).click();
	}

	@Then("^Enter password and submit$")
	public void enter_password_and_submit() throws Throwable {
		driver.findElement(By.className("form-control has-feedback")).sendKeys("Madhu@25");
		driver.findElement(By.xpath("//*[@id=\"reactPageContent\"]/div/div/form/div/div[3]/button")).click();
		Thread.sleep(3000);
	}
	@Then("^click on logout$")
	public void click_on_logout() throws Throwable {
		Thread.sleep(3000);
	    driver.findElement(By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[3]/div/div")).click();
	}
}
